## This software comes AS IS in the hope that it will be useful WITHOUT ANY WARRANTY, 
## NOT even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
## Please understand that there may still be bugs and errors. Use it at your own risk. 
## We take no responsibility for any errors or omissions in this code or for any misfortune 
## that may befall you or others as a result of its use. Please send comments and report 
## bugs to Krzysztof Bartoszek at krzbar@protonmail.ch .

source("732A90_ComputationalStatisticsHT2023_Lecture05codeSlide13a.R")
hist(stat,50,col=gray(0.8),freq=FALSE,ylab="",xlab="stat",cex.axis=1.5,cex.lab=1.5,main="")
segments(stat0, 0.007, 100, 0.007,lwd=3,col="red")
segments(stat0, 0.007, stat0, -1,lwd=3,lty=2,col="red")
segments(quantile(stat,probs=0.95), 0.005, 100, 0.005,lwd=3,col="blue")
segments(quantile(stat,probs=0.95), 0.005, quantile(stat,probs=0.95), -1,lwd=3,lty=2,col="blue")
legend("topright",col=c("red","blue"),pch=19,legend=c("stat0","95% quantile"),bty="n",cex=1.5)
